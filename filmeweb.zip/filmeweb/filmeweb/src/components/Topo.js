import styles from '../styles/Components.module.css'
export default function Topo() {
    return (
        <div className={styles.topo}>
            <h1>filmeWeb</h1>
        </div>
    )
}
