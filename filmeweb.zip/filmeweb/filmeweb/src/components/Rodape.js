import styles from '../styles/Components.module.css'
export default function Rodape() {
    return (
        <footer className={styles.rodape} >
            <p> Trabalho Final de Frameworks 2 – Prof. Ricardo - IFMS Dourados.</p>
            <p>Milena da Silva Lima</p>

        </footer>

    )
}
